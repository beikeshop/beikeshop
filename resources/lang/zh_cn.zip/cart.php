<?php
/**
 * cart.php
 *
 * @copyright  2022 beikeshop.com - All Rights Reserved
 * @link       https://beikeshop.com
 * @author     Edward Yang <yangjin@guangda.work>
 * @created    2022-08-26 15:25:29
 * @modified   2022-08-26 15:25:29
 */

return [
    'sku_id'    => 'SKU ID',
    'quantity'  => '购买数量',
    'stock_out' => '库存不足',
];
