<?php
/**
 * rma_reason.php
 *
 * @copyright  2022 beikeshop.com - All Rights Reserved
 * @link       https://beikeshop.com
 * @author     TL <mengwb@guangda.work>
 * @created    2022-08-16 17:22:41
 * @modified   2022-08-16 17:22:41
 */

return [
    'rma_reasons_index'  => '原因列表',
    'rma_reasons_create' => '创建原因',
    'rma_reasons_update' => '更新原因',
    'rma_reasons_delete' => '删除原因',
];
