<?php
/**
 * country.php
 *
 * @copyright  2022 beikeshop.com - All Rights Reserved
 * @link       https://beikeshop.com
 * @author     TL <mengwb@guangda.work>
 * @created    2022-08-29 17:21:38
 * @modified   2022-08-29 17:21:38
 */
return [
    'country_name'     => '国家名称',

    'countries_index'  => '国家列表',
    'countries_create' => '创建国家',
    'countries_update' => '更新国家',
    'countries_delete' => '删除国家',
];
