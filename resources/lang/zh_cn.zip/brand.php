<?php
/**
 * brand.php
 *
 * @copyright  2022 beikeshop.com - All Rights Reserved
 * @link       https://beikeshop.com
 * @author     Edward Yang <yangjin@guangda.work>
 * @created    2022-08-26 17:33:32
 * @modified   2022-08-26 17:33:32
 */

return [
    'name'         => '品牌名称',
    'icon'         => '图标',
    'first_letter' => '首字母',
];
